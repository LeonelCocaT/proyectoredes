import socket
import threading

host = '127.0.0.1'
port = 55556 

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Crea un socket TCP
server.bind((host, port))
server.listen()
print(f"El servidor está corriendo en {host}:{port}")


clients = []
usernames = []


def broadcast(message, sender_client):

 
    for receiver_client in clients:
  
        if receiver_client != sender_client:
            try:
                receiver_client.send(message)
            except:
       
                remove_client(receiver_client)


def remove_client(client):

    if client in clients:
        index = clients.index(client)
        username = usernames[index]
        
        clients.remove(client)
        usernames.remove(username)
        client.close()
        
    
        message = f"ChatBot: {username} ha abandonado el chat.".encode('utf-8')
        broadcast(message, client)
        print(f"Usuario desconectado: {username}")


def handle_messages(client):

    while True:
        try:
          
            message = client.recv(1024)
            
 
            if not message:
                remove_client(client)
                break

            print(f"Recibido: {message.decode('utf-8')}")
            
          
            broadcast(message, client)
            
        except:
  
            remove_client(client)
            break



def receive_connections():

    while True:
        try:
    
            client, address = server.accept()
            

            username_data = client.recv(1024)
            
            if not username_data:
                client.close()
                continue

            username = username_data.decode('utf-8')
            
    
            clients.append(client)
            usernames.append(username)

            print(f"Nuevo usuario conectado: {username} con {str(address)}")

        
            join_message = f"ChatBot: {username} se ha unido al chat".encode('utf-8')
            broadcast(join_message, client)
            
            
            client.send('Conectado exitosamente.'.encode('utf-8'))

  
            thread = threading.Thread(target=handle_messages, args=(client,))
            thread.start()

        except Exception as e:
      
            print(f"Error durante la conexión o autenticación: {e}")
            pass 


if __name__ == '__main__':
    receive_connections()