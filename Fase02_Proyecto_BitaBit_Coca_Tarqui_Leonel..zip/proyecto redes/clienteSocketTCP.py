import socket
import threading 

host = '127.0.0.1'
port = 55556 


username = input("ingrese su nombre de usuario: ")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:

    client.connect((host,port))

    client.send(username.encode('utf-8')) 
    

    initial_message = client.recv(1024).decode('utf-8')
    print(f"Servidor: {initial_message}")

except ConnectionRefusedError:
    print(f"ERROR: Falló la conexión. Servidor inactivo en {host}:{port}.")
    exit()
except Exception as e:
    print(f"Error durante la conexión inicial: {e}")
    exit()


def receive_messages():
    while True:
        try:
            message = client.recv(1024).decode('utf-8')
     
            print(message)
        except:
            print("error al conectar con el servidor o desconectado")
            client.close()
            break

def write_messages():
    while True:

        message = f"{username}: {input('')}"
        client.send(message.encode('utf-8'))


receive_thread = threading.Thread(target=receive_messages)
receive_thread.start()

write_thread = threading.Thread(target=write_messages)
write_thread.start()